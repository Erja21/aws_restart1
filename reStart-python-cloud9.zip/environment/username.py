'''username= (input("type user name:"))
password= (input("type password name:"))

usern=("1234erik")
passw=("Bigd1234")

if username==usern and password==passw:
    print("you are the right user")
else:
    print("forget it mate")'''
    
'''var=1
while var<=10 :
    var=var+1

    print(var)'''
    
import random

num=random.randint(1,10)
ans='y'

while ans=='y' or ans=='y' :
    guess=int(input("guess number :"))
    
    if num==guess :
        print("correct")
        break
    
    else:
        print("wrong")
        ans=input("do you want to continue?? [y/n:")
    