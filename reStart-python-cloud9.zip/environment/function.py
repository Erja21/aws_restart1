'''print("Hi Saraswati")

def square() :
    number= int(input("enter value :"))
    result= number*number
    print("square :", result)
    
square()
print()
print("have another go ")
square()

print()
print("last try")
square()

print()
print("you did it")
print()
print("THUMBS UP!!!!")'''


    # TODO: write code...

