age= int(input("Enter age:"))

if age>=18:
    print("have a cold beer")
else:
    print("sorry mate, you have to wait")