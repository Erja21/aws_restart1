myfruitlist = ["apple", "banana", "mango"]
print(myfruitlist)
print(type(myfruitlist))

print(myfruitlist[0])
print(myfruitlist[1])
print(myfruitlist[2])
myfruitlist[2] = "orange"
print(myfruitlist)