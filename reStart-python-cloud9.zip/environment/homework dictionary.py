mydictionary = { 
    "Tommy" : 8,
    "Peter" : 5,
    "Jeff" : 4,
    "Jim" : 9,
    "Ben" : 3
}

print(mydictionary)


total = (sum(mydictionary.values()))
print(total)

average = total / 5
print(average)