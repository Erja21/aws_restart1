#list
myfruitlist = ["apple", "banana", "mango"]
print(myfruitlist)
print(type(myfruitlist))

print(myfruitlist[0])
print(myfruitlist[1])
print(myfruitlist[2])
myfruitlist[2] = "orange"
print(myfruitlist)

#tuple type

myfinalanswertuple = ("apple", "banana","pineapple")
print(myfinalanswertuple)
print(type(myfinalanswertuple))

print(myfinalanswertuple[0])
print(myfinalanswertuple[1])
print(myfinalanswertuple[2])

#dictionary

myfavoritefruitDictionary = {
    "Akua" : "Apple",
    "Saanvi" : "Banana",
    "Paulo" : "Pineappale"
}
print(myfavoritefruitDictionary)
print(type(myfavoritefruitDictionary))

print(myfavoritefruitDictionary["Akua"])
print(myfavoritefruitDictionary["Saanvi"])
print(myfavoritefruitDictionary["Paulo"])