#print ("python has three numeric types: int, float, and complex")
L1= [1,2,3,4]
print(L1)

print(id(L1))

L1.append(10)

L1.insert(3,2)
print(L1)

L1.pop()
print(L1)

L1.remove(3)
print(L1)